# Arquivo: database.py - VERSÃO CORRIGIDA
import sqlite3
from sqlite3 import Error
import pandas as pd
import os
import sys
from datetime import datetime

def get_application_path():
    """Obtém o caminho base da aplicação, funcionando tanto em desenvolvimento quanto compilado"""
    if getattr(sys, "frozen", False):
        # Se estiver rodando como executável (compilado)
        application_path = os.path.dirname(sys.executable)
    else:
        # Se estiver rodando em desenvolvimento
        application_path = os.path.dirname(os.path.abspath(__file__))
    return application_path

class DatabaseManager:
    def __init__(self, db_file="app_rest_gyn.db"):
        # Definir o caminho do banco de dados
        app_path = get_application_path()
        # Se estiver compilado, usar a pasta 'app' dentro do diretório do executável
        if getattr(sys, "frozen", False):
            self.db_file = os.path.join(app_path, "app", db_file)
        else:
            self.db_file = os.path.join(app_path, db_file)

        print(f"Caminho do banco de dados: {self.db_file}")
        
        # Criar as tabelas e popular dados padrão
        self.create_tables()
        self.populate_default_data_safe()  # MÉTODO SEGURO
        
        # Verificar a tabela de base de cálculo
        self.verificar_tabela_base_calculo()
    
    def create_connection(self):
        try:
            # Garantir que o diretório existe
            os.makedirs(os.path.dirname(self.db_file), exist_ok=True)
            conn = sqlite3.connect(self.db_file)
            return conn
        except Error as e:
            print(f"Erro ao conectar ao banco de dados: {e}")
            return None

    def limpar_duplicatas_base_calculo(self):
        """Remove registros duplicados da tabela tb_base_calculo"""
        conn = self.create_connection()
        if conn is not None:
            try:
                cursor = conn.cursor()
                
                # Primeiro, vamos ver quantos duplicados temos
                cursor.execute("""
                    SELECT descricao, COUNT(*) as qtd
                    FROM tb_base_calculo 
                    GROUP BY descricao 
                    HAVING COUNT(*) > 1
                """)
                duplicados = cursor.fetchall()
                
                if duplicados:
                    print(f"Encontrados {len(duplicados)} tipos de registros duplicados:")
                    for desc, qtd in duplicados:
                        print(f"  - '{desc}': {qtd} registros")
                    
                    # Remover duplicados mantendo apenas o primeiro registro de cada tipo
                    cursor.execute("""
                        DELETE FROM tb_base_calculo 
                        WHERE id NOT IN (
                            SELECT MIN(id) 
                            FROM tb_base_calculo 
                            GROUP BY descricao
                        )
                    """)
                    
                    registros_removidos = cursor.rowcount
                    conn.commit()
                    print(f"Removidos {registros_removidos} registros duplicados")
                    return True
                else:
                    print("Nenhum registro duplicado encontrado na tabela tb_base_calculo")
                    return True
                    
            except Exception as e:
                print(f"Erro ao limpar duplicatas: {e}")
                conn.rollback()
                return False
            finally:
                conn.close()
        return False

    def limpar_todas_duplicatas(self):
        """Remove duplicatas de todas as tabelas de configuração"""
        tabelas_config = [
            ('tb_base_calculo', 'descricao'),
            ('tb_tipo_de_servico', 'descricao'),
            ('tb_uf', 'UF'),
            ('tb_tipo_de_recolhimento', 'recolhimento')
        ]
        
        conn = self.create_connection()
        if conn is not None:
            try:
                cursor = conn.cursor()
                total_removidos = 0
                
                for tabela, campo in tabelas_config:
                    print(f"\nVerificando duplicatas em {tabela}...")
                    
                    # Verificar duplicados
                    cursor.execute(f"""
                        SELECT {campo}, COUNT(*) as qtd
                        FROM {tabela} 
                        GROUP BY {campo} 
                        HAVING COUNT(*) > 1
                    """)
                    duplicados = cursor.fetchall()
                    
                    if duplicados:
                        print(f"  Encontrados {len(duplicados)} tipos duplicados:")
                        for valor, qtd in duplicados:
                            print(f"    - '{valor}': {qtd} registros")
                        
                        # Remover duplicados
                        cursor.execute(f"""
                            DELETE FROM {tabela} 
                            WHERE id NOT IN (
                                SELECT MIN(id) 
                                FROM {tabela} 
                                GROUP BY {campo}
                            )
                        """)
                        
                        removidos = cursor.rowcount
                        total_removidos += removidos
                        print(f"  Removidos {removidos} registros duplicados de {tabela}")
                    else:
                        print(f"  Nenhuma duplicata encontrada em {tabela}")
                
                conn.commit()
                print(f"\nTotal de registros duplicados removidos: {total_removidos}")
                return True
                
            except Exception as e:
                print(f"Erro ao limpar duplicatas: {e}")
                conn.rollback()
                return False
            finally:
                conn.close()
        return False

    def insert_klb_tomador(self):
        """
        Insere o tomador KLB ACCOUTING na base de dados
        
        :return: True se a inserção foi bem-sucedida, False caso contrário
        """
        print("Inserindo tomador KLB ACCOUTING...")
        
        # Verificar primeiro se já existe um tomador com este CNPJ
        conn = self.create_connection()
        if conn is not None:
            try:
                c = conn.cursor()
                c.execute("SELECT id FROM tb_config_tomador WHERE cnpj = ?", ('09238316000190',))
                exists = c.fetchone()
                
                if exists:
                    print(f"Tomador KLB já existe com ID {exists[0]}")
                    return True
                    
                # Verificar se a tabela possui coluna email
                c.execute("PRAGMA table_info(tb_config_tomador)")
                columns = [info[1] for info in c.fetchall()]
                
                # Adicionar coluna email se não existir
                if 'email' not in columns:
                    try:
                        c.execute("ALTER TABLE tb_config_tomador ADD COLUMN email TEXT")
                        print("Coluna 'email' adicionada à tabela tb_config_tomador")
                    except Exception as e:
                        print(f"Erro ao adicionar coluna 'email': {e}")
                
                # Inserir tomador KLB
                if 'email' in columns:
                    c.execute("""
                        INSERT INTO tb_config_tomador 
                        (razao_social, cnpj, cae_inscricao, usuario_prefeitura, email, data_atualizacao)
                        VALUES (?, ?, ?, ?, ?, datetime('now'))
                    """, (
                        '',
                        '',
                        '',
                        '',
                        ''
                    ))
                else:
                    c.execute("""
                        INSERT INTO tb_config_tomador 
                        (razao_social, cnpj, cae_inscricao, usuario_prefeitura, data_atualizacao)
                        VALUES (?, ?, ?, ?, datetime('now'))
                    """, (
                        'KLB ACCOUTING CONTABILIDADE EMPRESARIAL EIRELI',
                        '09238316000190',
                        '2425459',
                        '53052749153'
                    ))
                
                conn.commit()
                print("Tomador KLB inserido com sucesso!")
                return True
                
            except Exception as e:
                print(f"Erro ao inserir tomador KLB: {e}")
                import traceback
                traceback.print_exc()
                conn.rollback()
                return False
            finally:
                conn.close()
        
        return False

    def create_tables(self):
        conn = self.create_connection()
        if conn is not None:
            try:
                c = conn.cursor()

                # Criar tabela de configuração do tomador
                c.execute("""
                    CREATE TABLE IF NOT EXISTS tb_config_tomador (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        razao_social TEXT NOT NULL,
                        cnpj TEXT NOT NULL,
                        cae_inscricao TEXT NOT NULL,
                        usuario_prefeitura TEXT NOT NULL,
                        data_atualizacao TEXT
                    )
                """)

                # Criar tabela UF
                c.execute("""
                    CREATE TABLE IF NOT EXISTS tb_uf (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        UF TEXT UNIQUE NOT NULL
                    )
                """)

                # Criar tabela Tipo de Serviço
                c.execute("""
                    CREATE TABLE IF NOT EXISTS tb_tipo_de_servico (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        descricao TEXT UNIQUE NOT NULL
                    )
                """)
                
                # Criar tabela Base de Cálculo (NOVA TABELA)
                c.execute("""
                    CREATE TABLE IF NOT EXISTS tb_base_calculo (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        descricao TEXT UNIQUE NOT NULL
                    )
                """)

                # Criar tabela Tipo de Recolhimento
                c.execute("""
                    CREATE TABLE IF NOT EXISTS tb_tipo_de_recolhimento (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        recolhimento TEXT UNIQUE NOT NULL
                    )
                """)

                # Criar tabela Código Município
                c.execute("""
                    CREATE TABLE IF NOT EXISTS tb_cod_municipio (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        UF TEXT,
                        municipio TEXT,
                        cod_municipio TEXT,
                        FOREIGN KEY (UF) REFERENCES tb_uf (UF)
                    )
                """)

                # Criar tabela de Fornecedores
                c.execute("""
                    CREATE TABLE IF NOT EXISTS tb_fornecedores (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        CNPJ TEXT UNIQUE,
                        descricao_fornecedor TEXT,
                        UF TEXT,
                        municipio TEXT,
                        cod_municipio TEXT,
                        fora_pais TEXT DEFAULT 'Não',
                        cadastrado_goiania TEXT DEFAULT 'Não',
                        FOREIGN KEY (UF) REFERENCES tb_uf (UF)
                    )
                """)

                # Criar tabela de Notas Fiscais (com o campo base_calculo)
                c.execute("""
                    CREATE TABLE IF NOT EXISTS tb_notas_fiscais (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        referencia TEXT,
                        cadastrado_goiania TEXT,
                        fora_pais TEXT,
                        cnpj TEXT,
                        fornecedor_id INTEGER,
                        inscricao_municipal TEXT,
                        tipo_servico TEXT,
                        base_calculo TEXT,
                        numero_nf TEXT,
                        dt_emissao TEXT,
                        dt_pagamento TEXT,
                        aliquota REAL,
                        valor_nf REAL,
                        recolhimento_id INTEGER,
                        recibo TEXT,
                        uf TEXT,
                        municipio TEXT,
                        cod_municipio TEXT,
                        FOREIGN KEY (fornecedor_id) REFERENCES tb_fornecedores (id),
                        FOREIGN KEY (recolhimento_id) REFERENCES tb_tipo_de_recolhimento (id)
                    )
                """)

                # Adicionar colunas caso tabela já exista e faltarem colunas
                try:
                    c.execute("ALTER TABLE tb_notas_fiscais ADD COLUMN base_calculo TEXT")
                except:
                    pass  # Coluna já existe
                
                try:
                    c.execute("ALTER TABLE tb_notas_fiscais ADD COLUMN fora_pais TEXT")
                except:
                    pass  # Coluna já existe
                
                try:
                    c.execute("ALTER TABLE tb_fornecedores ADD COLUMN fora_pais TEXT DEFAULT 'Não'")
                except:
                    pass  # Coluna já existe
                
                try:
                    c.execute("ALTER TABLE tb_fornecedores ADD COLUMN cadastrado_goiania TEXT DEFAULT 'Não'")
                except:
                    pass  # Coluna já existe

                # Verificar se já existe configuração de tomador
                c.execute("SELECT COUNT(*) FROM tb_config_tomador")
                if c.fetchone()[0] == 0:
                    # Inserir registro vazio para ser atualizado posteriormente
                    c.execute("""
                        INSERT INTO tb_config_tomador 
                        (razao_social, cnpj, cae_inscricao, usuario_prefeitura, data_atualizacao)
                        VALUES (?, ?, ?, ?, datetime('now'))
                    """, ("", "", "", ""))

                conn.commit()
            except Error as e:
                print(f"Erro ao criar tabelas: {e}")
            finally:
                conn.close()

    def get_all_tipos_servico(self):
        conn = self.create_connection()
        if conn is not None:
            try:
                c = conn.cursor()
                c.execute("SELECT descricao FROM tb_tipo_de_servico ORDER BY id")
                return [row[0] for row in c.fetchall()]
            except Exception as e:
                print(f"Erro ao buscar tipos de serviço: {e}")
                return []
            finally:
                conn.close()
        return []

    def get_all_bases_calculo(self):
        conn = self.create_connection()
        if conn is not None:
            try:
                c = conn.cursor()
                c.execute("SELECT descricao FROM tb_base_calculo ORDER BY id")
                return [row[0] for row in c.fetchall()]
            except Exception as e:
                print(f"Erro ao buscar bases de cálculo: {e}")
                return []
            finally:
                conn.close()
        return []            

    def populate_default_data_safe(self):
        """Versão segura que evita duplicatas ao popular dados padrão"""
        conn = self.create_connection()
        if conn is not None:
            try:
                c = conn.cursor()

                # UFs - Verificar antes de inserir
                c.execute("SELECT COUNT(*) FROM tb_uf")
                if c.fetchone()[0] == 0:
                    print("Inserindo UFs...")
                    ufs = [
                        "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA",
                        "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN",
                        "RS", "RO", "RR", "SC", "SP", "SE", "TO"
                    ]
                    c.executemany(
                        "INSERT INTO tb_uf (UF) VALUES (?)",
                        [(uf,) for uf in ufs]
                    )
                    print(f"Inseridas {len(ufs)} UFs")

                # Tipos de Serviço - Verificar antes de inserir
                c.execute("SELECT COUNT(*) FROM tb_tipo_de_servico")
                if c.fetchone()[0] == 0:
                    print("Inserindo tipos de serviço...")
                    tipos_servico = [
                        "00 - Normal",
                        "02 - Imune",
                        "03 - Art 54 do CTM",
                        "04 - Liminar",
                        "05 - Simples Nacional",
                        "07 - ISS Estimado",
                        "08 - Não Incidência",
                        "09 - Isento",
                        "10 - Imposto Fixo"
                    ]
                    c.executemany(
                        "INSERT INTO tb_tipo_de_servico (descricao) VALUES (?)",
                        [(tipo,) for tipo in tipos_servico]
                    )
                    print(f"Inseridos {len(tipos_servico)} tipos de serviço")
                
                # Bases de Cálculo - Verificar antes de inserir
                c.execute("SELECT COUNT(*) FROM tb_base_calculo")
                if c.fetchone()[0] == 0:
                    print("Inserindo bases de cálculo...")
                    bases_calculo = [
                        "00 - Base de cálculo normal",
                        "01 - Publicidade e propaganda",
                        "02 - Representação comercial",
                        "03 - Corretagem de seguro",
                        "04 - Construção civil",
                        "05 - Call Center",
                        "06 - Estação Digital",
                        "07 - Serviços de saúde (órtese e prótese)"
                    ]
                    c.executemany(
                        "INSERT INTO tb_base_calculo (descricao) VALUES (?)",
                        [(base,) for base in bases_calculo]
                    )
                    print(f"Inseridas {len(bases_calculo)} bases de cálculo")
            
                # Tipos de Recolhimento - Verificar antes de inserir
                c.execute("SELECT COUNT(*) FROM tb_tipo_de_recolhimento")
                if c.fetchone()[0] == 0:
                    print("Inserindo tipos de recolhimento...")
                    recolhimentos = ["Recolhimento"]
                    c.executemany(
                        "INSERT INTO tb_tipo_de_recolhimento (recolhimento) VALUES (?)",
                        [(rec,) for rec in recolhimentos]
                    )
                    print(f"Inseridos {len(recolhimentos)} tipos de recolhimento")
                
                # Check if we need to add test tomador data
                c.execute("SELECT COUNT(*) FROM tb_config_tomador WHERE razao_social != ''")
                if c.fetchone()[0] == 0:
                    print("Adicionando tomador de teste...")
                    c.execute("""
                        INSERT INTO tb_config_tomador 
                        (razao_social, cnpj, cae_inscricao, usuario_prefeitura, data_atualizacao)
                        VALUES (?, ?, ?, ?, datetime('now'))
                    """, ("Empresa Teste", "12345678901234", "INSCRIÇÃO-001", "usuario_teste"))
                    print("Tomador de teste adicionado com sucesso!")

                conn.commit()
                print("Dados padrão populados com sucesso!")
                
            except Error as e:
                print(f"Erro ao popular dados: {e}")
                conn.rollback()
            finally:
                conn.close()

    # MÉTODO ANTIGO MANTIDO PARA COMPATIBILIDADE (MAS NÃO USADO)
    def populate_default_data(self):
        """MÉTODO ANTIGO - NÃO USAR MAIS - Mantido apenas para compatibilidade"""
        print("AVISO: Método populate_default_data() antigo foi chamado. Use populate_default_data_safe()")
        pass

    def get_database_status(self):
        """Retorna o status completo do banco de dados"""
        conn = self.create_connection()
        if conn is not None:
            try:
                c = conn.cursor()
                
                status = {}
                
                # Verificar cada tabela
                tabelas = [
                    'tb_config_tomador',
                    'tb_uf', 
                    'tb_tipo_de_servico',
                    'tb_base_calculo',
                    'tb_tipo_de_recolhimento',
                    'tb_cod_municipio',
                    'tb_fornecedores',
                    'tb_notas_fiscais'
                ]
                
                for tabela in tabelas:
                    c.execute(f"SELECT COUNT(*) FROM {tabela}")
                    count = c.fetchone()[0]
                    status[tabela] = count
                
                # Verificar duplicatas em tabelas críticas
                for tabela_config in [
                    ('tb_base_calculo', 'descricao'),
                    ('tb_tipo_de_servico', 'descricao'),
                    ('tb_uf', 'UF')
                ]:
                    tabela, campo = tabela_config
                    c.execute(f"""
                        SELECT COUNT(*) FROM (
                            SELECT {campo}, COUNT(*) as qtd
                            FROM {tabela} 
                            GROUP BY {campo} 
                            HAVING COUNT(*) > 1
                        )
                    """)
                    duplicatas = c.fetchone()[0]
                    status[f"{tabela}_duplicatas"] = duplicatas
                
                return status
                
            except Exception as e:
                print(f"Erro ao verificar status do banco: {e}")
                return {}
            finally:
                conn.close()
        return {}
            
    def verificar_tabela_base_calculo(self):
        """Verifica se a tabela tb_base_calculo existe e tem dados"""
        conn = self.create_connection()
        if conn is not None:
            try:
                c = conn.cursor()
                
                # Verificar se a tabela existe
                c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='tb_base_calculo'")
                tabela_existe = c.fetchone() is not None
                print(f"Tabela tb_base_calculo existe: {tabela_existe}")
                
                if tabela_existe:
                    # Verificar se tem dados
                    c.execute("SELECT COUNT(*) FROM tb_base_calculo")
                    count = c.fetchone()[0]
                    print(f"Quantidade de registros na tabela tb_base_calculo: {count}")
                    
                    # Listar registros
                    if count > 0:
                        c.execute("SELECT id, descricao FROM tb_base_calculo ORDER BY id")
                        registros = c.fetchall()
                        print("Registros encontrados:")
                        for registro in registros:
                            print(f" - ID: {registro[0]}, Descrição: {registro[1]}")
                    
                    # Verificar duplicatas
                    c.execute("""
                        SELECT descricao, COUNT(*) as qtd
                        FROM tb_base_calculo 
                        GROUP BY descricao 
                        HAVING COUNT(*) > 1
                    """)
                    duplicados = c.fetchall()
                    if duplicados:
                        print(f"ATENÇÃO: Encontradas {len(duplicados)} descrições duplicadas:")
                        for desc, qtd in duplicados:
                            print(f"  - '{desc}': {qtd} registros")
                
                return tabela_existe, count if tabela_existe else 0
            except Exception as e:
                print(f"Erro ao verificar tabela tb_base_calculo: {e}")
            finally:
                conn.close()
        return False, 0

    # RESTO DOS MÉTODOS MANTIDOS IGUAIS...
    def get_all_ufs(self):
        conn = self.create_connection()
        if conn is not None:
            try:
                c = conn.cursor()
                c.execute("SELECT UF FROM tb_uf ORDER BY UF")
                return [row[0] for row in c.fetchall()]
            finally:
                conn.close()
        return []

    def get_all_recolhimentos(self):
        conn = self.create_connection()
        if conn is not None:
            try:
                c = conn.cursor()
                c.execute("SELECT recolhimento FROM tb_tipo_de_recolhimento")
                return [row[0] for row in c.fetchall()]
            finally:
                conn.close()
        return []

    def get_municipios_by_uf(self, uf):
        conn = self.create_connection()
        if conn is not None:
            try:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT municipio, cod_municipio 
                    FROM tb_cod_municipio 
                    WHERE UF = ? 
                    ORDER BY municipio
                """, (uf,))
                return cursor.fetchall()
            finally:
                conn.close()
        return []

    def get_fornecedor_by_cnpj(self, cnpj):
        conn = self.create_connection()
        if conn is not None:
            try:
                c = conn.cursor()
                c.execute("""
                    SELECT descricao_fornecedor, UF, municipio, cod_municipio
                    FROM tb_fornecedores 
                    WHERE CNPJ = ?
                """, (cnpj,))
                return c.fetchone()
            finally:
                conn.close()
        return None

    def get_cod_municipio(self, uf, municipio):
        conn = self.create_connection()
        if conn is not None:
            try:
                c = conn.cursor()
                c.execute("""
                    SELECT cod_municipio 
                    FROM tb_cod_municipio 
                    WHERE UF = ? AND municipio = ?
                """, (uf, municipio))
                result = c.fetchone()
                return result[0] if result else None
            finally:
                conn.close()
        return None

    def insert_fornecedor(self, cnpj, descricao, uf, municipio, cod_municipio, fora_pais, cadastrado_goiania):
        conn = self.create_connection()
        if conn is not None:
            try:
                c = conn.cursor()
                c.execute("""
                    SELECT id FROM tb_fornecedores 
                    WHERE CNPJ = ?
                """, (cnpj,))

                existing_supplier = c.fetchone()

                if existing_supplier:
                    c.execute("""
                        UPDATE tb_fornecedores 
                        SET descricao_fornecedor = ?,
                            UF = ?,
                            municipio = ?,
                            cod_municipio = ?,
                            fora_pais = ?,
                            cadastrado_goiania = ?
                        WHERE CNPJ = ?
                    """, (descricao, uf, municipio, cod_municipio, fora_pais, cadastrado_goiania, cnpj))
                    fornecedor_id = existing_supplier[0]
                else:
                    c.execute("""
                        INSERT INTO tb_fornecedores 
                        (CNPJ, descricao_fornecedor, UF, municipio, cod_municipio, fora_pais, cadastrado_goiania)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (cnpj, descricao, uf, municipio, cod_municipio, fora_pais, cadastrado_goiania))
                    fornecedor_id = c.lastrowid

                conn.commit()
                return fornecedor_id

            except Exception as e:
                print(f"Erro ao inserir/atualizar fornecedor: {e}")
                conn.rollback()
                return None
            finally:
                conn.close()
        return None

    def insert_nota_fiscal(self, dados):
        conn = self.create_connection()
        if conn is not None:
            try:
                # Validar e limpar o campo 'referencia'
                referencia = dados.get('referencia', '').strip()
                if not referencia:
                    print("Erro: Referência não pode ser vazia")
                    return False

                cursor = conn.cursor()
                query = """
                INSERT INTO tb_notas_fiscais (
                    referencia, cadastrado_goiania, fora_pais, cnpj, fornecedor_id, 
                    inscricao_municipal, tipo_servico, base_calculo, numero_nf, 
                    dt_emissao, dt_pagamento, aliquota, valor_nf, recolhimento_id, 
                    recibo, uf, municipio, cod_municipio
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 
                        (SELECT id FROM tb_tipo_de_recolhimento WHERE recolhimento = ?), 
                        ?, ?, ?, ?)
                """
                
                # Remover quebras de linha do CNPJ
                cnpj = dados['CNPJ'].strip().replace('\n', '')

                values = (
                    referencia, 
                    dados.get('cadastrado_goiania', 'Não'), 
                    dados.get('fora_pais', 'Não'), 
                    cnpj, 
                    dados['Fornecedor_ID'], 
                    dados.get('Inscrição Municipal', ''), 
                    dados['Tipo de Serviço'], 
                    dados['Base de Cálculo'], 
                    dados['Nº NF'], 
                    dados['Dt. Emissão'], 
                    dados['Dt. Pagamento'], 
                    dados['Aliquota'], 
                    dados['Valor NF'], 
                    dados['Recolhimento'], 
                    dados.get('RECIBO', ''), 
                    dados['UF'], 
                    dados['Município'], 
                    dados['Código Município']
                )

                cursor.execute(query, values)
                conn.commit()
                return True
            except Exception as e:
                print(f"Erro ao inserir nota fiscal: {e}")
                print(f"Dados recebidos: {dados}")
                return False
            finally:
                conn.close()
        return False

    def update_nota_fiscal(self, id_nota, dados):
        conn = self.create_connection()
        if conn is not None:
            try:
                cursor = conn.cursor()

                # Map the incoming field names to database field names
                field_mapping = {
                    "Referencia": "referencia",
                    "Cadastrado em Goiania": "cadastrado_goiania",
                    "CNPJ": "cnpj",
                    "Inscrição Municipal": "inscricao_municipal",
                    "Tipo de Serviço": "tipo_servico",
                    "Base de Cálculo": "base_calculo",
                    "Nº NF": "numero_nf",
                    "Dt. Emissão": "dt_emissao",
                    "Dt. Pagamento": "dt_pagamento",
                    "Aliquota": "aliquota",
                    "Valor NF": "valor_nf",
                    "Recolhimento": "recolhimento",
                    "RECIBO": "recibo",
                    "UF": "uf",
                    "Município": "municipio",
                    "Código Município": "cod_municipio",
                    "fora_pais": "fora_pais",
                }

                # Create a new dictionary with mapped field names
                mapped_dados = {}
                for old_key, new_key in field_mapping.items():
                    if old_key in dados:
                        mapped_dados[new_key] = dados[old_key]
                    elif new_key in dados:
                        # Handle cases where the key is already in the new format
                        mapped_dados[new_key] = dados[new_key]

                # Buscar fornecedor_id baseado no CNPJ
                cursor.execute("""
                    SELECT id FROM tb_fornecedores 
                    WHERE CNPJ = ?
                    """, (mapped_dados.get("cnpj", ""),))
                fornecedor_result = cursor.fetchone()
                fornecedor_id = fornecedor_result[0] if fornecedor_result else None

                # Buscar recolhimento_id
                cursor.execute("""
                    SELECT id FROM tb_tipo_de_recolhimento 
                    WHERE recolhimento = ?
                    """, (mapped_dados.get("recolhimento", ""),))
                recolhimento_result = cursor.fetchone()
                recolhimento_id = recolhimento_result[0] if recolhimento_result else None

                # Update query with proper field names
                cursor.execute("""
                    UPDATE tb_notas_fiscais SET
                        referencia = ?,
                        cadastrado_goiania = ?,
                        fora_pais = ?,
                        cnpj = ?,
                        fornecedor_id = ?,
                        inscricao_municipal = ?,
                        tipo_servico = ?,
                        base_calculo = ?,
                        numero_nf = ?,
                        dt_emissao = ?,
                        dt_pagamento = ?,
                        aliquota = ?,
                        valor_nf = ?,
                        recolhimento_id = ?,
                        recibo = ?,
                        uf = ?,
                        municipio = ?,
                        cod_municipio = ?
                    WHERE id = ?
                    """, (
                    mapped_dados.get("referencia", ""),
                    mapped_dados.get("cadastrado_goiania", "Não"),
                    mapped_dados.get("fora_pais", "Não"),
                    mapped_dados.get("cnpj", ""),
                    fornecedor_id,
                    mapped_dados.get("inscricao_municipal", ""),
                    mapped_dados.get("tipo_servico", ""),
                    mapped_dados.get("base_calculo", ""),
                    mapped_dados.get("numero_nf", ""),
                    mapped_dados.get("dt_emissao", ""),
                    mapped_dados.get("dt_pagamento", ""),
                    mapped_dados.get("aliquota", 0.0),
                    mapped_dados.get("valor_nf", 0.0),
                    recolhimento_id,
                    mapped_dados.get("recibo", ""),
                    mapped_dados.get("uf", ""),
                    mapped_dados.get("municipio", ""),
                    mapped_dados.get("cod_municipio", ""),
                    id_nota,
                ))

                conn.commit()
                return True
            except Exception as e:
                print(f"Erro na atualização: {e}")
                conn.rollback()
                return False
            finally:
                conn.close()
        return False

    def delete_nota_fiscal(self, id_nota):
        conn = self.create_connection()
        if conn is not None:
            try:
                c = conn.cursor()
                # Exclui usando o ID da nota
                c.execute("""
                    DELETE FROM tb_notas_fiscais 
                    WHERE id = ?
                """, (id_nota,))

                # Verifica se algum registro foi afetado
                affected_rows = c.rowcount
                conn.commit()

                print(f"Registros excluídos: {affected_rows}")
                return affected_rows > 0
            except Exception as e:
                print(f"Erro ao excluir nota fiscal: {e}")
                conn.rollback()
                return False
            finally:
                conn.close()
        return False

    def get_all_notas_fiscais(self):
        conn = self.create_connection()
        if conn is not None:
            try:
                # Verificar primeiro se a tabela existe
                cursor = conn.cursor()
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='tb_notas_fiscais'")
                table_exists = cursor.fetchone()

                if not table_exists:
                    print("A tabela tb_notas_fiscais não existe.")
                    return pd.DataFrame()

                # Verificar se a tabela está vazia
                cursor.execute("SELECT COUNT(*) FROM tb_notas_fiscais")
                count = cursor.fetchone()[0]

                if count == 0:
                    print("A tabela tb_notas_fiscais está vazia.")
                    # Retornar DataFrame vazio com as colunas corretas
                    return pd.DataFrame(columns=[
                        "id", "referencia", "cadastrado_goiania", "fora_pais",
                        "cnpj", "descricao_fornecedor", "tipo_servico", "base_calculo",
                        "numero_nf", "dt_emissao", "dt_pagamento", "aliquota",
                        "valor_nf", "recolhimento"
                    ])

                # Consulta SQL ajustada para incluir ID e base_calculo
                query = """
                    SELECT 
                        nf.id,
                        nf.referencia,
                        nf.cadastrado_goiania,
                        nf.fora_pais,
                        nf.cnpj,
                        f.descricao_fornecedor,
                        nf.tipo_servico,
                        nf.base_calculo,
                        nf.numero_nf,
                        nf.dt_emissao,
                        nf.dt_pagamento,
                        nf.aliquota,
                        nf.valor_nf,
                        tr.recolhimento
                    FROM tb_notas_fiscais nf
                    LEFT JOIN tb_fornecedores f ON nf.fornecedor_id = f.id
                    LEFT JOIN tb_tipo_de_recolhimento tr ON nf.recolhimento_id = tr.id
                    ORDER BY nf.dt_emissao DESC
                """

                df = pd.read_sql_query(query, conn)
                return df
            except Exception as e:
                print(f"Erro detalhado na consulta: {str(e)}")
                return pd.DataFrame(columns=[
                    "id", "referencia", "cadastrado_goiania", "fora_pais",
                    "cnpj", "descricao_fornecedor", "tipo_servico", "base_calculo", 
                    "numero_nf", "dt_emissao", "dt_pagamento", "aliquota",
                    "valor_nf", "recolhimento"
                ])
            finally:
                conn.close()
        return pd.DataFrame()

    def get_nota_fiscal_by_id(self, id_nota):
        conn = self.create_connection()
        if conn is not None:
            try:
                cursor = conn.cursor()
                query = """
                    SELECT 
                        nf.id,
                        nf.referencia,
                        nf.cadastrado_goiania,
                        nf.fora_pais,
                        nf.cnpj,
                        nf.fornecedor_id,
                        nf.inscricao_municipal,
                        nf.tipo_servico,
                        nf.base_calculo,
                        nf.numero_nf,
                        nf.dt_emissao,
                        nf.dt_pagamento,
                        nf.aliquota,
                        nf.valor_nf,
                        nf.recolhimento_id,
                        f.descricao_fornecedor,
                        f.UF,
                        f.municipio,
                        f.cod_municipio,
                        tr.recolhimento,
                        nf.recibo
                    FROM tb_notas_fiscais nf
                    LEFT JOIN tb_fornecedores f ON nf.fornecedor_id = f.id
                    LEFT JOIN tb_tipo_de_recolhimento tr ON nf.recolhimento_id = tr.id
                    WHERE nf.id = ?
                """
                cursor.execute(query, (id_nota,))
                resultado = cursor.fetchone()
                print("Resultado da query:", resultado)  # Debug
                return resultado
            except Exception as e:
                print(f"Erro ao buscar nota fiscal: {e}")
                return None
            finally:
                conn.close()
        return None

    def export_to_excel(self, filename):
        """Exporta as notas fiscais para um arquivo Excel"""
        conn = self.create_connection()
        if conn is not None:
            try:
                query = """
                    SELECT 
                        nf.referencia as "Referência",
                        nf.cadastrado_goiania as "Cadastrado em Goiânia",
                        nf.fora_pais as "Fora do País",
                        nf.cnpj as "CNPJ",
                        f.descricao_fornecedor as "Fornecedor",
                        f.UF as "UF",
                        f.municipio as "Município",
                        f.cod_municipio as "Código Município",
                        nf.inscricao_municipal as "Inscrição Municipal",
                        nf.tipo_servico as "Tipo de Serviço",
                        nf.base_calculo as "Base de Cálculo",
                        nf.numero_nf as "Número NF",
                        nf.dt_emissao as "Data Emissão",
                        nf.dt_pagamento as "Data Pagamento",
                        nf.aliquota as "Alíquota",
                        nf.valor_nf as "Valor NF",
                        tr.recolhimento as "Recolhimento",
                        nf.recibo as "Recibo"
                    FROM tb_notas_fiscais nf
                    LEFT JOIN tb_fornecedores f ON nf.fornecedor_id = f.id
                    LEFT JOIN tb_tipo_de_recolhimento tr ON nf.recolhimento_id = tr.id
                    ORDER BY nf.dt_emissao DESC
                """

                # Ler dados para DataFrame
                df = pd.read_sql_query(query, conn)

                # Formatações
                if "Alíquota" in df.columns:
                    df["Alíquota"] = df["Alíquota"].apply(
                        lambda x: f"{float(x):.2f}" if pd.notnull(x) else ""
                    )
                if "Valor NF" in df.columns:
                    df["Valor NF"] = df["Valor NF"].apply(
                        lambda x: f"{float(x):.2f}" if pd.notnull(x) else ""
                    )

                for col in ["Data Emissão", "Data Pagamento"]:
                    if col in df.columns:
                        df[col] = pd.to_datetime(df[col], errors='coerce').dt.strftime("%d/%m/%Y")

                # Exportar para Excel
                df.to_excel(filename, index=False, sheet_name="Notas Fiscais")

                try:
                    # Ajustar largura das colunas se openpyxl estiver disponível
                    from openpyxl import load_workbook
                    from openpyxl.utils import get_column_letter

                    wb = load_workbook(filename)
                    ws = wb["Notas Fiscais"]
                    
                    for idx, col in enumerate(df.columns):
                        col_letter = get_column_letter(idx + 1)
                        max_length = max(
                            df[col].astype(str).apply(len).max(), len(str(col))
                        )
                        ws.column_dimensions[col_letter].width = max_length + 2
                    
                    wb.save(filename)
                except ImportError:
                    print("openpyxl não está disponível, não foi possível ajustar as colunas")
                except Exception as e:
                    print(f"Erro ao ajustar largura das colunas: {e}")

                return True
            except Exception as e:
                print(f"Erro ao exportar para Excel: {e}")
                return False
            finally:
                conn.close()
        return False
    
    def limpar_notas_fiscais(self):
        """Remove todas as notas fiscais do banco de dados"""
        conn = self.create_connection()
        if conn is not None:
            try:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM tb_notas_fiscais")
                conn.commit()
                print(f"Registros excluídos: {cursor.rowcount}")
                return True
            except Exception as e:
                print(f"Erro ao limpar tabela de notas fiscais: {e}")
                conn.rollback()
                return False
            finally:
                conn.close()
        return False

    def limpar_tomadores(self):
        """Remove todos os tomadores do banco de dados"""
        conn = self.create_connection()
        if conn is not None:
            try:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM tb_config_tomador")
                conn.commit()
                print(f"Tomadores excluídos: {cursor.rowcount}")
                return True
            except Exception as e:
                print(f"Erro ao limpar tabela de tomadores: {e}")
                conn.rollback()
                return False
            finally:
                conn.close()
        return False

    def import_municipios_from_txt(self, file_path):
        """Importa municípios de um arquivo de texto no formato: CODIGO;MUNICIPIO;UF"""
        conn = self.create_connection()
        if conn is not None:
            try:
                cursor = conn.cursor()
                count = 0

                with open(file_path, "r", encoding="utf-8") as file:
                    for line_number, line in enumerate(file, 1):
                        try:
                            # Remove espaços em branco e quebras de linha
                            line = line.strip()

                            if not line:
                                continue

                            # Divide usando ponto e vírgula
                            parts = line.split(";")

                            if len(parts) == 3:
                                cod_municipio, municipio, uf = parts
                                # Remove espaços extras
                                municipio = municipio.strip()
                                uf = uf.strip()
                                cod_municipio = cod_municipio.strip()

                                print(f"Processando: Código={cod_municipio}, Município={municipio}, UF={uf}")

                                cursor.execute("""
                                    INSERT OR IGNORE INTO tb_cod_municipio (UF, municipio, cod_municipio)
                                    VALUES (?, ?, ?)
                                """, (uf, municipio, cod_municipio))
                                count += 1
                            else:
                                print(f"Erro na linha {line_number}: formato inválido - {line}")
                        except Exception as e:
                            print(f"Erro ao processar linha {line_number}: {e}")
                    
                    conn.commit()
                    print(f"Total de municípios importados: {count}")
                    return True

            except Exception as e:
                print(f"Erro detalhado ao importar municípios: {str(e)}")
                conn.rollback()
                return False
            finally:
                conn.close()
        return False

    def get_all_tomadores(self):
        """Retorna todos os tomadores cadastrados no sistema"""
        conn = self.create_connection()
        if conn is not None:
            try:
                c = conn.cursor()
                c.execute("SELECT * FROM tb_config_tomador ORDER BY razao_social")
                return c.fetchall()
            except Exception as e:
                print(f"Erro ao buscar tomadores: {e}")
                return []
            finally:
                conn.close()
        return []

    def delete_tomador(self, tomador_id):
        """Remove um tomador do banco de dados"""
        conn = self.create_connection()
        if conn is not None:
            try:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM tb_config_tomador WHERE id = ?", (tomador_id,))
                conn.commit()
                return True
            except Exception as e:
                print(f"Erro ao excluir tomador: {e}")
                conn.rollback()
                return False
            finally:
                conn.close()
        return False

    def update_tomador(self, dados):
        """Atualiza um tomador existente"""
        conn = self.create_connection()
        if conn is not None:
            try:
                cursor = conn.cursor()
                cursor.execute("""
                    UPDATE tb_config_tomador 
                    SET razao_social = ?,
                        cnpj = ?,
                        cae_inscricao = ?,
                        usuario_prefeitura = ?,
                        data_atualizacao = datetime('now')
                    WHERE id = ?
                """, (
                    dados["razao_social"],
                    dados["cnpj"],
                    dados["inscricao"],
                    dados["usuario"],
                    dados["id"],
                ))
                conn.commit()
                return True
            except Exception as e:
                print(f"Erro ao atualizar tomador: {e}")
                conn.rollback()
                return False
            finally:
                conn.close()
        return False

    def insert_tomador(self, dados):
        """Insere um novo tomador"""
        conn = self.create_connection()
        if conn is not None:
            try:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO tb_config_tomador 
                    (razao_social, cnpj, cae_inscricao, usuario_prefeitura, data_atualizacao)
                    VALUES (?, ?, ?, ?, datetime('now'))
                """, (
                    dados["razao_social"],
                    dados["cnpj"],
                    dados["inscricao"],
                    dados["usuario"],
                ))
                conn.commit()
                return True
            except Exception as e:
                print(f"Erro ao inserir tomador: {e}")
                conn.rollback()
                return False
            finally:
                conn.close()
        return False

    def export_to_txt(self, filename):
        """
        Exporta as notas fiscais para um arquivo TXT no formato específico
        
        :param filename: Caminho do arquivo TXT a ser criado
        :return: True se exportado com sucesso, False caso contrário
        """
        conn = self.create_connection()
        if conn is not None:
            try:
                # Obter todas as notas fiscais
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT 
                        n.referencia,
                        n.cnpj,
                        f.descricao_fornecedor,
                        n.inscricao_municipal,
                        n.tipo_servico,
                        n.base_calculo,
                        n.numero_nf,
                        n.dt_emissao,
                        n.dt_pagamento,
                        n.aliquota,
                        n.valor_nf,
                        tr.recolhimento,
                        n.recibo
                    FROM tb_notas_fiscais n
                    LEFT JOIN tb_fornecedores f ON n.fornecedor_id = f.id
                    LEFT JOIN tb_tipo_de_recolhimento tr ON n.recolhimento_id = tr.id
                    ORDER BY n.id
                """)
                
                notas = cursor.fetchall()
                
                # Obter dados do tomador
                cursor.execute("SELECT razao_social, cnpj FROM tb_config_tomador LIMIT 1")
                tomador = cursor.fetchone()
                if not tomador:
                    raise Exception("Dados do tomador não encontrados")
                
                with open(filename, 'w', encoding='utf-8') as f:
                    # Escrever cabeçalho (Header)
                    data_atual = datetime.now().strftime('%Y%m%d')
                    ref_header = f"H{data_atual}KLB ACCOUTING CONTABILIDADE EMPRESARIAL EIRELI".ljust(120)
                    ref_header += "09238316000190 N".ljust(120)
                    ref_header += f"\n{data_atual}marcelo.santos@kblcontabilidade.com.br2.9.7N\n"
                    f.write(ref_header)
                    
                    # Escrever registros de detalhe
                    seq = 1
                    for nota in notas:
                        # Formatar campos conforme necessário
                        cnpj = ''.join(filter(str.isdigit, str(nota[1] or '')))  # Apenas números do CNPJ
                        fornecedor = str(nota[2] or '').ljust(50)[:50]  # Nome do fornecedor limitado a 50 caracteres
                        valor = int(float(nota[10] or 0) * 100)  # Valor em centavos
                        data_emissao = datetime.strptime(nota[7], '%Y-%m-%d').strftime('%Y%m%d') if nota[7] else ''
                        data_pagamento = datetime.strptime(nota[8], '%Y-%m-%d').strftime('%Y%m%d') if nota[8] else ''
                        
                        # Montar linha de detalhe conforme o formato fornecido
                        detalhe = f"D{str(seq).zfill(5)}"  # Sequencial com 5 dígitos
                        detalhe += "0" * 14  # 14 zeros
                        detalhe += cnpj.ljust(14)  # CNPJ do fornecedor
                        detalhe += fornecedor  # Nome do fornecedor
                        detalhe += cnpj.ljust(18)  # CNPJ formatado
                        detalhe += str(valor).zfill(14)  # Valor da nota
                        detalhe += data_emissao  # Data de emissão
                        detalhe += data_pagamento  # Data de pagamento
                        detalhe += " " * 25  # Espaços em branco
                        detalhe += "J" + " " * 25  # J + espaços
                        detalhe += "05002"  # Código fixo
                        detalhe += data_emissao  # Data de emissão novamente
                        detalhe += "00350300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
                        detalhe += str(valor).zfill(14)  # Valor da nota novamente
                        detalhe += "0" * 56  # 56 zeros finais
                        detalhe += "\n"
                        
                        f.write(detalhe)
                        seq += 1
                    
                    # Escrever trailer
                    trailer = f"T{str(seq-1).zfill(6)}000000000\n"
                    f.write(trailer)
                
                print(f"Arquivo TXT exportado com sucesso: {filename}")
                return True
                
            except Exception as e:
                print(f"Erro ao exportar para TXT: {str(e)}")
                import traceback
                traceback.print_exc()
                return False
            finally:
                conn.close()
        return False

    def get_all_fornecedores(self):
        """Retorna todos os fornecedores cadastrados"""
        conn = self.create_connection()
        if conn is not None:
            try:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT id, CNPJ, descricao_fornecedor, UF, municipio, cod_municipio, 
                           fora_pais, cadastrado_goiania
                    FROM tb_fornecedores
                    ORDER BY descricao_fornecedor
                """)
                fornecedores = cursor.fetchall()
                return [
                    {
                        'id': f[0],
                        'cnpj': f[1],
                        'descricao_fornecedor': f[2],
                        'uf': f[3],
                        'municipio': f[4],
                        'cod_municipio': f[5],
                        'fora_pais': f[6] or 'Não',
                        'cadastrado_goiania': f[7] or 'Não'
                    }
                    for f in fornecedores
                ]
            except Exception as e:
                print(f"Erro ao buscar fornecedores: {e}")
                return []
            finally:
                conn.close()
        return []

    def get_fornecedor_by_id(self, fornecedor_id):
        """Retorna um fornecedor específico pelo ID"""
        conn = self.create_connection()
        if conn is not None:
            try:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT id, CNPJ, descricao_fornecedor, UF, municipio, cod_municipio, 
                           fora_pais, cadastrado_goiania
                    FROM tb_fornecedores
                    WHERE id = ?
                """, (fornecedor_id,))
                f = cursor.fetchone()
                if f:
                    return {
                        'id': f[0],
                        'cnpj': f[1],
                        'descricao_fornecedor': f[2],
                        'uf': f[3],
                        'municipio': f[4],
                        'cod_municipio': f[5],
                        'fora_pais': f[6] or 'Não',
                        'cadastrado_goiania': f[7] or 'Não'
                    }
            except Exception as e:
                print(f"Erro ao buscar fornecedor: {e}")
            finally:
                conn.close()
        return None

    def update_fornecedor(self, dados):
        """Atualiza os dados de um fornecedor"""
        conn = self.create_connection()
        if conn is not None:
            try:
                cursor = conn.cursor()
                cursor.execute("""
                    UPDATE tb_fornecedores
                    SET CNPJ = ?,
                        descricao_fornecedor = ?,
                        UF = ?,
                        municipio = ?,
                        cod_municipio = ?,
                        fora_pais = ?,
                        cadastrado_goiania = ?
                    WHERE id = ?
                """, (
                    dados['cnpj'],
                    dados['descricao_fornecedor'],
                    dados['uf'],
                    dados['municipio'],
                    dados['cod_municipio'],
                    dados['fora_pais'],
                    dados['cadastrado_goiania'],
                    dados['id']
                ))
                conn.commit()
                return True
            except Exception as e:
                print(f"Erro ao atualizar fornecedor: {e}")
                conn.rollback()
                return False
            finally:
                conn.close()
        return False

    def delete_fornecedor(self, fornecedor_id):
        """Exclui um fornecedor pelo ID"""
        conn = self.create_connection()
        if conn is not None:
            try:
                cursor = conn.cursor()
                # Verificar se existem notas fiscais vinculadas
                cursor.execute("SELECT COUNT(*) FROM tb_notas_fiscais WHERE fornecedor_id = ?", (fornecedor_id,))
                if cursor.fetchone()[0] > 0:
                    print("Não é possível excluir o fornecedor pois existem notas fiscais vinculadas")
                    return False
                
                cursor.execute("DELETE FROM tb_fornecedores WHERE id = ?", (fornecedor_id,))
                conn.commit()
                return True
            except Exception as e:
                print(f"Erro ao excluir fornecedor: {e}")
                conn.rollback()
                return False
            finally:
                conn.close()
        return False

    def limpar_fornecedores(self):
        """Limpa todos os fornecedores que não possuem notas fiscais vinculadas"""
        conn = self.create_connection()
        if conn is not None:
            try:
                cursor = conn.cursor()
                # Excluir apenas fornecedores sem notas fiscais
                cursor.execute("""
                    DELETE FROM tb_fornecedores
                    WHERE id NOT IN (
                        SELECT DISTINCT fornecedor_id 
                        FROM tb_notas_fiscais 
                        WHERE fornecedor_id IS NOT NULL
                    )
                """)
                conn.commit()
                return True
            except Exception as e:
                print(f"Erro ao limpar fornecedores: {e}")
                conn.rollback()
                return False
            finally:
                conn.close()
        return False