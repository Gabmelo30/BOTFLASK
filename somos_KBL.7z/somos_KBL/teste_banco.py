#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de teste imediato para o DatabaseManager
Salve como: teste_banco.py
Execute: python teste_banco.py
"""

# Importe seu DatabaseManager
from database import DatabaseManager

def main():
    print("🧪 TESTE IMEDIATO DO BANCO DE DADOS")
    print("=" * 50)
    
    try:
        # 1. Criar instância do DatabaseManager
        print("🔧 Criando instância do DatabaseManager...")
        db = DatabaseManager()
        
        # 2. Diagnóstico rápido
        print("\n🔍 Executando diagnóstico...")
        diagnostico_ok = db.diagnosticar_banco_rapido()
        
        if not diagnostico_ok:
            print("\n⚠️  PROBLEMA DETECTADO! Executando correção automática...")
            
            # 3. Correção completa
            resultado_correcao = db.corrigir_problema_completo()
            
            if not resultado_correcao:
                print("\n❌ FALHA NA CORREÇÃO!")
                print("Verifique:")
                print("- Permissões de escrita no diretório")
                print("- Espaço em disco disponível")
                print("- Se o SQLite está instalado corretamente")
                return False
        
        # 4. Teste final
        print("\n🧪 TESTE FINAL DOS MÉTODOS...")
        
        # Testar bases de cálculo
        bases = db.get_all_bases_calculo()
        print(f"✅ get_all_bases_calculo(): {len(bases)} itens encontrados")
        
        if bases:
            print("📋 Primeiras 5 bases de cálculo:")
            for i, base in enumerate(bases[:5], 1):
                print(f"   {i}. {base}")
        
        # Testar tipos de serviço
        tipos = db.get_all_tipos_servico()
        print(f"✅ get_all_tipos_servico(): {len(tipos)} itens encontrados")
        
        # Testar UFs
        ufs = db.get_all_ufs()
        print(f"✅ get_all_ufs(): {len(ufs)} itens encontrados")
        
        print("\n" + "=" * 50)
        print("🎉 SUCESSO! O banco está funcionando perfeitamente!")
        print("💡 Agora você pode:")
        print("   ✅ Carregar bases de cálculo nos seus formulários")
        print("   ✅ Inserir notas fiscais normalmente")
        print("   ✅ Usar todos os métodos do DatabaseManager")
        
        return True
        
    except Exception as e:
        print(f"\n❌ ERRO CRÍTICO: {e}")
        import traceback
        traceback.print_exc()
        
        print("\n💡 POSSÍVEIS SOLUÇÕES:")
        print("1. Verifique se o arquivo database.py está no mesmo diretório")
        print("2. Instale as dependências: pip install sqlite3 pandas")
        print("3. Execute como administrador se houver problemas de permissão")
        print("4. Verifique se há espaço em disco suficiente")
        
        return False

if __name__ == "__main__":
    sucesso = main()
    
    if sucesso:
        print("\n🚀 PRONTO PARA USAR!")
    else:
        print("\n🔧 CORREÇÕES NECESSÁRIAS!")
        
    input("\nPressione Enter para sair...")